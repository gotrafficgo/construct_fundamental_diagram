function [TrajectoryData, DataInformation] = LoadCAData(root, VehNumber_Lane, whichSeed, whichLane)
       
    filePath = fullfile(root, 'trajectory_data', 'CA', whichSeed, ['Record_All_' VehNumber_Lane '_Lane' whichLane, '.csv']);

    TrajectoryData = readtable(filePath);    
    TrajectoryData = table2array(TrajectoryData);
    
    DataInformation.dataset = 'CA';
    DataInformation.site = whichSeed;
    DataInformation.lane = whichLane;
    DataInformation.data = num2str(VehNumber_Lane);

    DataInformation.TimeStart = 1;
    DataInformation.TimeEnd = floor(1000);
    
    DataInformation.PositionStart = 1;
    DataInformation.PositionEnd = floor(max(TrajectoryData(:,3)));

    DataInformation.MaxColorBar = 25*3.6;    
    DataInformation.MaxSpeed = 25*3.6;  

end


